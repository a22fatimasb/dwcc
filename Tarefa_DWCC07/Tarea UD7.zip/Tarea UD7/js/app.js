// Código de validaciones del formulario

// Envio de datos con XMLHttpRequest
